# -*- coding: utf-8 -*-

from flask import Flask, render_template
import urllib
import youtube_dl

urllib.urlretrieve("http://www.kmooc.kr/static/images/logo.png", "static/kmooc1.jpg")
urllib.urlretrieve("http://www.kmooc.kr/static/images/univ_intro/univ_top_kaist.png", "static/kmooc2.jpg")
urllib.urlretrieve("http://www.kmooc.kr/static/images/univ_intro/univ_logo_kaist.png", "static/kmooc3.jpg")

app = Flask(__name__)

ydl = youtube_dl.YoutubeDL({'outtmpl': 'static/%(id)s.%(ext)s'})
with ydl:
    result = ydl.extract_info(
        'https://youtu.be/JZUOL1-ZSWA',
        download=True # We just want to extract the info
    )
    
ydl2 = youtube_dl.YoutubeDL({'outtmpl': 'static/%(id)s.%(ext)s'})
with ydl2:
    result2 = ydl2.extract_info(
        'https://youtu.be/tKLRQs_nOxM',
        download=True # We just want to extract the info
    )

if 'entries' in result:
    # Can be a playlist or a list of videos
    video = result['entries'][0]
else:
    # Just a video
    video = result

if 'entries' in result2:
    # Can be a playlist or a list of videos
    video2 = result2['entries'][0]
else:
    # Just a video
    video2 = result2


print(video)
video_url = video['url']
print(video_url)

print(video2)
video_url2 = video2['url']
print(video_url2)

@app.route("/")
def hompage():
    return render_template("index.html")
    
@app.route("/main/")
def hompage2():
    return render_template("main.html")
    
@app.route("/submain/")
def hompage3():
    return render_template("submain.html")
    
if __name__ == "__main__":
    app.run()

        